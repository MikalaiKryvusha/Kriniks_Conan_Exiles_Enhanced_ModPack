Camera Behind - Third Person Camera Control
ConanCameraControl, a Lua mod for UE4SS

WHAT IT DOES
  Puts the third-person camera directly behind your character instead of over
  the shoulder, and gives you full control of the zoom range. Character,
  camera and crosshair line up, so you see what you aim at. Everything is
  tuned live on the numpad and saved automatically.

REQUIREMENTS
  Conan Exiles Enhanced (UE 5.6). Not for the legacy UE4 version.
  UE4SS - tested on 3.0.1 build 1127: https://github.com/UE4SS-RE/RE-UE4SS
  Singleplayer. Not tested on servers.

INSTALLATION
  1. Install UE4SS into ConanSandbox\Binaries\Win64.
  2. Drop this ConanCameraControl folder into
     ConanSandbox\Binaries\Win64\ue4ss\Mods\
  3. Add "ConanCameraControl : 1" to ue4ss\Mods\mods.txt, or just keep the
     enabled.txt that ships in this folder.
  4. Start the game.

  DO NOT USE UE4SS HOT RELOAD (Ctrl+R) ON THIS MOD. It stacks the mod's timer
  loop instead of replacing it, and the game will come down after a while.
  Restart the game instead.

CONTROLS - NUMPAD (NumLock on)
  8 / 2          camera back / forward
  4 / 6          camera left / right
  9 / 3          camera up / down
  7 / 1          pivot up / down
  5              centre it - zero the sideways offset
  + / -          distance
  /              save the current setup
  0              restore the saved setup
  Ctrl + 8/2, 4/6, 9/3   move the PIVOT instead of the camera
  Ctrl + 5       reset the pivot
  Ctrl + 0       re-acquire the camera component (emergency)

  The * key is left free on purpose - the game uses it for chat.

CAMERA OFFSET VS PIVOT
  SocketOffset moves THE CAMERA and rides along when you turn, so the
  character keeps its place on screen. TargetOffset moves THE ORBIT CENTRE in
  world space, so the character sits lower in frame - which is how the classic
  TES IV: Oblivion framing is built. Neither turns the camera: aim always
  follows the mouse.

COMPATIBILITY NOTE - ENHANCED ARMORY AND ARSENAL
  EAA ships its own "Extended Camera Zoom" and takes the spring arm over,
  which breaks the zoom limit. This mod detects it and stops just its camera
  component; the rest of EAA keeps working. Set mute_foreign_camera = false in
  config.lua if you prefer EAA's zoom.

CONFIG
  config.lua holds every value and is rewritten by the mod itself whenever you
  tune something on the numpad. Comments you add there will not survive.

CREDITS
  Built by Krinik with Claude (Anthropic). Free to use and to learn from.
